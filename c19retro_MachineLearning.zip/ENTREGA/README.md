Autores:
    - Carlos Eduardo Arismendi Sánchez
    - Antón Chernysh
    - Sergio Cortés Espinosa

Tecnologías utilizadas:
    - Perceptrón.
    - Redes neuronales (backpropagation, regularización, validación).
        