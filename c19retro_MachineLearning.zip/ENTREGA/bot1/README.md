Para ejecutarlo:
	./C19RETRO.robot rom/assault.bin
